#!/bin/sh

DIRNAME="`pwd`"
/etc/init.d/upsmon stop
esxcli software vib update --no-sig-check -v "${DIRNAME}/upsmon-2.7.4-2.1.1.i386.vib"

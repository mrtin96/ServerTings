#!/bin/sh

/etc/init.d/upsmon stop
esxcli software vib remove -f -n upsmon
